# Social Networking Site

## Features
- User Registration
- Create Posts
- View Posts
- Like Posts

## Installation
npm install
npm start

Open browser: http://localhost:3000
