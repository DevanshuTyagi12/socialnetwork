const express = require("express");
const bodyParser = require("body-parser");
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

let users = [];
let posts = [];

app.use(express.static("public"));

app.post("/register", (req, res) => {
  const { username } = req.body;
  users.push({ username });
  res.json({ message: "User registered" });
});

app.post("/post", (req, res) => {
  const { username, content } = req.body;
  posts.push({ id: posts.length + 1, username, content, likes: 0 });
  res.json({ message: "Post created" });
});

app.get("/posts", (req, res) => {
  res.json(posts);
});

app.post("/like/:id", (req, res) => {
  const post = posts.find(p => p.id == req.params.id);
  if (post) post.likes++;
  res.json({ message: "Liked" });
});

app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
